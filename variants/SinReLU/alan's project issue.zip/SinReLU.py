from activations import SineReLU
import numpy as np
from random import random
from scipy import stats
import tqdm
from w_init import glorot
from optimize import gradient_descent
import pandas as pd

class Node:
    def __init__(self) -> None:
        self.decay = np.float32(float(1.0 - (random() * 0.1)))
        self.activation = SineReLU(decay=self.decay)
        self.fire_state: bool = False
        self.fire_log: list = list()
        self.output: np.float32 = np.float32(0.0)

    def update(self, dt_data) -> tuple:
        output, fire = self.activation.activate(dt_data)
        self.fire_state: bool = fire
        self.output: np.float32 = output
        self.fire_log.append(self.output)
        return (output, fire)
    
    def params(self) -> tuple:
        return (self.decay, self.fire_state, self.fire_log, self.output)

class Net:
    def __init__(self, n_inputs:int, n_hidden:int, n_outputs:int) -> None:
        self.n_inputs:int = n_inputs
        self.n_hidden:int = n_hidden
        self.n_outputs:int = n_outputs

        self.total_nodes:int = self.n_inputs + self.n_hidden + self.n_outputs
        self.input_keys = [i for i in range(0, self.n_inputs)]
        start = int(self.total_nodes - self.n_outputs)
        self.output_keys = [i for i in range(start, self.total_nodes)]

        self.nodes:dict = dict()
        for i in range(self.total_nodes):
            self.nodes[str(i)] = Node()
        self.node_keys:list = list(self.nodes.keys())

        # Init weight mat with glorot (xavier) dist
        self.w_matrix:np.ndarray = glorot((self.total_nodes, self.total_nodes))
        # Need to eliminate input and output connections:
        self.w_matrix[:self.n_inputs, :self.n_inputs] = np.nan
        self.w_matrix[-self.n_outputs:, -self.n_outputs:] = np.nan
        # Elinimate recurrent
        node_list:list = [i for i in range(self.total_nodes)]
        self.w_matrix[node_list, node_list] = np.nan

        self.backlog_cache:list = list()
        self.tick:float = 0.00
        self.dt:float = 0.10
        self.step_counter = 0

    def step(self, data) -> None:
        cache = list()
        # Run Backlog!
        # MAKE SURE INPUT IS RUN ALONG WITH BACKLOG!
        if self.step_counter >= 1 and len(list(self.backlog_cache.keys())) >= 1:
            for k in list(self.backlog_cache.keys()):
                sends = self.backlog_cache[k]
                for recive_k in list(self.nodes.keys()):
                    if recive_k != k:
                        weights = self.w_matrix[int(k)][int(recive_k)]
                        self.nodes[recive_k].update(sends * weights)
                        # Skip ones already ran in backlogs
                        cache.pop(recive_k)
                        print(recive_k)

        for k in cache:
            self.nodes[k].update(data)

        for k in list(self.nodes.keys()):
            if self.nodes[k].fire_state:
                self.backlog_cache[k] = self.nodes[k].output
                try:
                    for in_k in range(self.input_keys):
                        self.backlog_cache[in_k] = self.nodes[in_k].output
                except:
                    continue

    def weight_update(self, y_true) -> None:
        if self.step_counter >= 2:
            bias_matrix = self.w_matrix
            for k1 in range(self.total_nodes):
                x:list = self.nodes[str(k1)].fire_log
                weight_pairs = list ()
                for k2 in range(self.total_nodes):
                    y:list = self.nodes[str(k2)].fire_log
                    weight_pairs.append(y)
                bias_matrix += np.multiply(stats.pearsonr(x, y).correlation, 0.99)

        y_preds = []
        y_true = y_true.to_numpy()
        for k in self.output_keys:
            y_preds.append(np.float32(self.nodes[str(k)].output))
        print(y_preds)
        
        y_preds = np.asarray(y_preds, dtype=np.float32)
        self.w_matrix = gradient_descent.optimize_weights(y_preds, self.w_matrix, y_true, LR, num_iterations=100)
        self.w_matrix += bias_matrix
        #self.w_matrix = (self.w_matrix-np.min(self.w_matrix))/(np.max(self.w_matrix)-np.min(self.w_matrix))

    def normalize_outputs(self) -> np.ndarray:
        # Normalize output of all OUTPUT nodes:
        # Scale: (-1, 1]
        # Method: Min max
        outputs = []
        for k in self.output_keys:
            outputs.append(self.nodes[str(k)].output)
        outputs = np.ndarray(outputs)
        outputs = (outputs-np.min(outputs))/(np.max(outputs)-np.min(outputs))
        return outputs

    def run(self, batched_data):
        for batch in tqdm.tqdm(batched_data):
            batch: pd.DataFrame
            # Run data through network
            for i in range(batch.shape[1]-1):
                if self.step_counter <= 2:
                    for i in range(2):
                        self.step(batch.iloc[i])
                else:
                    self.step(batch.iloc[i])
                self.weight_update(batch.iloc[i])
            self.step_counter += 1
            raise
        # END TRAIN & START SAVING
        np.save("./weights.npy", self.w_matrix)
        # Dump all NODE params as well
        node_params = dict()
        for k in self.node_keys:
            node_params[str(k)] = self.nodes[str(k)].params()

        import csv
        with open("node_params.csv", 'w', newline='') as csvfile:
            writer = csv.writer(csvfile)
            # Write header row with keys
            writer.writerow(['Key'] + [f'Value_{i+1}' for i in range(len(next(iter(node_params.values()))))])
            # Write data rows
            for key, value in node_params.items():
                writer.writerow([key] + list(value))

if __name__ == "__main__":
    global LR
    LR = 0.01
    train = pd.read_csv("./dataset/train.csv").drop(columns=['date'])
    train = (train - np.mean(train)) / np.std(train)
    test = pd.read_csv("./dataset/test.csv").drop(columns=['date'])
    test = (test - np.mean(test)) / np.std(test)
    from preprocessing.batch import sliding_window
    train_batched = sliding_window.batch(train, 4, 2)
    test_batched = sliding_window.batch(train, 4, 2)

    net = Net(4, 64, 4)

    net.run(train_batched)